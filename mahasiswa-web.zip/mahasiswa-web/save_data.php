<?php
include 'proses/initDB.php';

$id = isset($_GET['id']) ? $_GET['id'] : null;
$mahasiswa = null;

if ($id) {
    $query = "SELECT * FROM mahasiswa WHERE id = $id";
    $result = mysqli_query($koneksi, $query);
    if ($result && mysqli_num_rows($result) === 1) {
        $mahasiswa = mysqli_fetch_assoc($result);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $id ? 'Edit Data Mahasiswa' : 'Tambah Data Mahasiswa'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container d-flex align-items-center justify-content-center min-vh-100">
        <div class="card shadow-lg border-0 p-4" style="width: 100%; max-width: 600px;">
            <h2 class="text-center mb-4 text-primary fw-bold"><?php echo $id ? 'Edit Data Mahasiswa' : 'Tambah Data Mahasiswa'; ?></h2>
            <form action="proses/proses_save.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $id ? htmlspecialchars($mahasiswa['id']) : ''; ?>">

                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label for="nama" class="form-label fw-semibold">Nama</label>
                        <input type="text" id="nama" name="nama" class="form-control" placeholder="Masukkan nama" required value="<?php echo $id ? htmlspecialchars($mahasiswa['nama']) : ''; ?>">
                    </div>

                    <div class="col-md-6">
                        <label for="nim" class="form-label fw-semibold">NIM</label>
                        <input type="text" id="nim" name="nim" class="form-control" placeholder="Masukkan NIM" required value="<?php echo $id ? htmlspecialchars($mahasiswa['nim']) : ''; ?>">
                    </div>
                </div>

                <div class="mb-3">
                    <label for="tanggal_lahir" class="form-label fw-semibold">Tanggal Lahir</label>
                    <input type="date" id="tanggal_lahir" name="tanggal_lahir" class="form-control" required value="<?php echo $id ? htmlspecialchars($mahasiswa['tanggal_lahir']) : ''; ?>">
                </div>

                <div class="mb-3">
                    <label for="alamat" class="form-label fw-semibold">Alamat</label>
                    <textarea id="alamat" name="alamat" class="form-control" rows="3" placeholder="Masukkan alamat" required><?php echo $id ? htmlspecialchars($mahasiswa['alamat']) : ''; ?></textarea>
                </div>

                <div class="mb-3">
                    <label for="jurusan" class="form-label fw-semibold">Jurusan</label>
                    <input type="text" id="jurusan" name="jurusan" class="form-control" placeholder="Masukkan jurusan" required value="<?php echo $id ? htmlspecialchars($mahasiswa['jurusan']) : ''; ?>">
                </div>

                <div class="mb-4">
                    <label for="gambar" class="form-label fw-semibold">Gambar</label>
                    <?php if ($id && $mahasiswa['gambar']): ?>
                        <div class="mb-2">
                            <img src="uploads/<?php echo htmlspecialchars($mahasiswa['gambar']); ?>" alt="Gambar <?php echo htmlspecialchars($mahasiswa['nama']); ?>" width="100" class="img-thumbnail rounded">
                        </div>
                    <?php endif; ?>
                    <input type="file" id="gambar" name="gambar" class="form-control">
                </div>

                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="submit" name="save" class="btn btn-primary btn-lg">Simpan</button>
                    <a href="home.php" class="btn btn-secondary btn-lg ms-md-2">Batal</a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
