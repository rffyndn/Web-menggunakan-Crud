<?php
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'mahasiswa_db';

$koneksi = mysqli_connect($host, $username, $password);

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
