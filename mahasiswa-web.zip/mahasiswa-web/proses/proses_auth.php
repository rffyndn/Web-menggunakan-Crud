<?php
include 'initDB.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $auth_type = isset($_POST['auth_type']) ? $_POST['auth_type'] : 'login';

    if ($auth_type === 'register') {
        $confirm_password = $_POST['confirm_password'];
        
        if ($password !== $confirm_password) {
            header("Location: ../register.php?error=password_mismatch");
            exit;
        }

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $check_user_query = "SELECT * FROM users WHERE username = '$username'";
        $check_user_result = mysqli_query($koneksi, $check_user_query);

        if (mysqli_num_rows($check_user_result) > 0) {
            header("Location: ../register.php?error=user_exists");
            exit;
        }

        $register_query = "INSERT INTO users (username, password) VALUES ('$username', '$hashed_password')";
        if (mysqli_query($koneksi, $register_query)) {
            $_SESSION['username'] = $username;
            header("Location: ../home.php");
            exit;
        } else {
            header("Location: ../register.php?error=registration_failed");
            exit;
        }

    } elseif ($auth_type === 'login') {
        $query = "SELECT * FROM users WHERE username = '$username'";
        $result = mysqli_query($koneksi, $query);

        if (mysqli_num_rows($result) === 1) {
            $user = mysqli_fetch_assoc($result);
            if (password_verify($password, $user['password'])) {
                $_SESSION['username'] = $username;
                header("Location: ../home.php");
                exit;
            } else {
                header("Location: ../login.php?error=invalid_credentials");
                exit;
            }
        } else {
            header("Location: ../login.php?error=invalid_credentials");
            exit;
        }
    }
}
?>
