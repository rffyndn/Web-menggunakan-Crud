<?php
include 'initDB.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? $_POST['id'] : null;
    $nama = $_POST['nama'];
    $nim = $_POST['nim'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $alamat = $_POST['alamat'];
    $jurusan = $_POST['jurusan'];
    $gambar = '';

    $upload_dir = '../uploads';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
        $gambar = $upload_dir . '/' . basename($_FILES['gambar']['name']);
        move_uploaded_file($_FILES['gambar']['tmp_name'], $gambar);
        $saveimg = basename($_FILES['gambar']['name']);
    }

    if ($id) {
        $query = "UPDATE mahasiswa SET 
            nama = '$nama', 
            nim = '$nim', 
            tanggal_lahir = '$tanggal_lahir', 
            alamat = '$alamat', 
            jurusan = '$jurusan', 
            gambar = '$saveimg' 
            WHERE id = $id";
    } else {
        $query = "INSERT INTO mahasiswa (nama, nim, tanggal_lahir, alamat, jurusan, gambar) 
            VALUES ('$nama', '$nim', '$tanggal_lahir', '$alamat', '$jurusan', '$gambar')";
    }

    mysqli_query($koneksi, $query);
    header("Location: ../home.php");
    exit;
}
?>
