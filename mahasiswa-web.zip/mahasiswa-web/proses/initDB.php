<?php
include 'koneksi.php';

$db_check = mysqli_select_db($koneksi, $dbname);
if (!$db_check) {
    $create_db_query = "CREATE DATABASE $dbname";
    if (mysqli_query($koneksi, $create_db_query)) {
        mysqli_select_db($koneksi, $dbname);
    } else {
        die("Gagal membuat database: " . mysqli_error($koneksi));
    }
}

$table_check_query = "SHOW TABLES LIKE 'mahasiswa'";
$table_check_result = mysqli_query($koneksi, $table_check_query);

if (mysqli_num_rows($table_check_result) == 0) {
    $create_table_query = "CREATE TABLE mahasiswa (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nama VARCHAR(100) NOT NULL,
        nim VARCHAR(20) NOT NULL,
        tanggal_lahir DATE NOT NULL,
        alamat TEXT NOT NULL,
        jurusan VARCHAR(100) NOT NULL,
        gambar VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    mysqli_query($koneksi, $create_table_query);
}

$user_table_check_query = "SHOW TABLES LIKE 'users'";
$user_table_check_result = mysqli_query($koneksi, $user_table_check_query);

if (mysqli_num_rows($user_table_check_result) == 0) {
    $create_user_table_query = "CREATE TABLE users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    mysqli_query($koneksi, $create_user_table_query);
}
?>
